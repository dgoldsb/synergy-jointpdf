models were loaded using the default COBRA toolbox readCbModel function or modified models were made as documented below

iFF708 - from http://129.16.106.142/models.php?c=S.cerevisiae, *invalid SBML*, modified by KS's make_models_consistent script (included)
iND750 - from bigg database on 1/13/12
iIN800 - iIN800.mat from Markus Herrgard on 6/24/2013 (modified from published version for improved COBRA Toolbox compatibility)
iMM904 - from bigg database
Yeast 4 - from yeast.sf.net
iAZ900 - from doi:10.1186/1752-0509-4-178 supplemental info
iMM904bs - from http://www.utoronto.ca/boonelab/data/szappanos/
Yeast 5 - from yeast.sf.net
iTO977 - from Markus Herrgard on 6/24/2013 (modified from published version for improved COBRA Toolbox compatibility)
Yeast 6 - from yeast.sf.net
Yeast 7 - from yeast.sf.net
biomodels.db - downloaded 11/21/13 from https://www.ebi.ac.uk/biomodels-main/BMID000000141353

Additional annotation was loaded using a modified readCbModel function, or copied from supplemental data published with models
NOTE: modified version only uses first ChEBI ID for mets with multiple, so this is lossy

generation of additional annotation fields as described in circos comparsison folder compare_Mets.m scripts

iMM ChEBI annotation was added from Y7 by matching ChEBI IDs.
